const express = require('express')
const app = express()
const port = 5000
const bodyparser = require('body-parser')
app.use(bodyparser.json())

//connection to database
const knex = require('knex')({
    client: 'mysql2',
    connection: {
      host : 'localhost',
      port : 3306,
      user : 'root',
      password : '',
      database : 'todo'
    }
  });


  //table of categories starts

  const table_category = 'categories'

  //get categories 
  app.get('/get_categories' , async (req , res) => {
  const categories = await knex.select('*')
    .from(table_category)
    res.send(categories)
  })


  //add category 
  app.post('/add_category' , async(req , res) => {
    const new_category = req.body
    try{ // because of our category name is unique in database so if we insert duplicate data we get an error thats why i used try catch

         const data = await knex(table_category).insert(new_category)
         const new_id = data[0]
         const new_data = await knex(table_category)
         .where('category_id', new_id)
         res.send(new_data)

    }
    catch{
        res.send("we already have this category")
    }
  })


  //delete by id
  app.delete('/delete_category/:category_id' , async(req , res) => {
    const category_id = req.params.category_id
   const data = await knex(table_category)
  .where('category_id', category_id)
  .del()
  res.send("deleted")
  })


  //update by id
  app.put('/update_category/:category_id' , async (req , res) => {
    const category_id = req.params.category_id
    const body = req.body
    try{// because of our category name is unique in database so if we insert duplicate data we get an error thats why i used try catch
       const data = await  knex(table_category)
        .where('category_id', category_id)
        .update(body)
        res.send("updated")
    }
    catch{
        res.send("we already have this category")
    }
   
  })

  //table of categories ends


  //table of contents of todo  starts

  const table_content = 'todo_content'

  //get all todo's
  app.get('/get_todos' , async (req , res) => {
   const todos = await knex.select('*')
    .from(table_content)
    res.send(todos)
  })

  //get todo by category
  app.get('/get_todos/:todo_category' , async(req , res) => {
    const todo_category = req.params.todo_category
    const data = await knex(table_content)
   .where('todo_category', todo_category)
   res.send(data)

  })

  //add todo
  app.post('/add_todo' , async(req , res) => {
    const body = req.body
    try{ // because this todo_category has relationship with another column in difference table if we insert different value we get ab error
    const data = await knex(table_content).insert(body)
    const new_id = data[0]
    const new_data = await knex(table_content)
    .where('todo_id', new_id)
     res.send(new_data)
    }
    catch{
        res.send('todo category not available')
    }
  })


  //delete todo by id
  app.delete('/delete_todo/:todo_id' , async(req , res) => {
   const todo_id = req.params.todo_id
   const data = await knex(table_content)
   .where('todo_id', todo_id)
   .del()
   res.send("deleted")
  })

  // update todo
  app.put('/update_todo/:todo_id' , async (req , res) => {
    const todo_id = req.params.todo_id
    const body = req.body
    try{ // because this todo_category has relationship with another column in difference table if we insert different value we get ab error
       const data = await  knex(table_content)
        .where('todo_id', todo_id)
        .update(body)
        res.send("updated")
    }
    catch{
        res.send('todo category not available')
    }
  })

  //table of contents of todo  ends


app.listen(port , ()=>{
    console.log("app running at port " + port)
})