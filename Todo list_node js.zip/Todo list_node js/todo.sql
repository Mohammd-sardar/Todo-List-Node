--
-- Database: `todo`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`) VALUES
(19, 'designs'),
(11, 'normal_life'),
(13, 'school'),
(12, 'work');

-- --------------------------------------------------------

--
-- Table structure for table `todo_content`
--

CREATE TABLE `todo_content` (
  `todo_id` int(11) NOT NULL,
  `todo_subject` varchar(255) NOT NULL,
  `todo_category` varchar(50) NOT NULL,
  `todo_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `todo_content`
--

INSERT INTO `todo_content` (`todo_id`, `todo_subject`, `todo_category`, `todo_date`) VALUES
(1, 'go to barber shop to cut your hair', 'normal_life', '2023-01-18'),
(2, 'go to shower', 'normal_life', '2023-01-17'),
(4, 'redesign a cover', 'work', '2023-02-20'),
(5, 'eat dinner', 'normal_life', '2023-02-20'),
(8, 'redesign a cover', 'designs', '2023-02-20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `todo_content`
--
ALTER TABLE `todo_content`
  ADD PRIMARY KEY (`todo_id`),
  ADD KEY `todo_category` (`todo_category`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `todo_content`
--
ALTER TABLE `todo_content`
  MODIFY `todo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `todo_content`
--
ALTER TABLE `todo_content`
  ADD CONSTRAINT `todo_content_ibfk_1` FOREIGN KEY (`todo_category`) REFERENCES `categories` (`category_name`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;


