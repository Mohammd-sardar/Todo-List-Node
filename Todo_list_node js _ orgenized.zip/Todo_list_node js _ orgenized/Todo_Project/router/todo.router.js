const express = require('express')
const app = express()

const todo = require('../controller/todo.controller')



  //table of contents of todo  starts


  //get all todo's
  app.get('/get_todos' , todo.getAllTodo())

  //get todo by category
  app.get('/get_todos/:todo_category' , todo.getTodoByCategory())

  //add todo
  app.post('/add_todo' , todo.addTodo())


  //delete todo by id
  app.delete('/delete_todo/:todo_id' , todo.deleteTodo())

  // update todo
  app.put('/update_todo/:todo_id' , todo.updateTodo())

  //table of contents of todo  ends

  module.exports = app