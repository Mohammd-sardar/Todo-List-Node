const express = require('express')
const app = express()



const categories = require('../controller/categories.controller')
 
 //table of categories starts

 
 //get categories 
 app.get('/get_categories' , categories.getAllCategories())


 //add category 
 app.post('/add_category' , categories.addCategory())


 //delete by id
 app.delete('/delete_category/:category_id' , categories.deleteCategory())


 //update by id
 app.put('/update_category/:category_id' , categories.updateCategory())

 //table of categories ends

 module.exports = app