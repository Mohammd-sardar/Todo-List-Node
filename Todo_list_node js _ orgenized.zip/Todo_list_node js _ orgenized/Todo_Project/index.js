const express = require('express')
const app = express()
const port = 5000
const bodyparser = require('body-parser')
app.use(bodyparser.json())

const categories = require('./router/categories.router')
const todo = require('./router/todo.router')

app.use('/' , categories)
app.use('/' , todo)




app.listen(port , ()=>{
    console.log("app running at port " + port)
})