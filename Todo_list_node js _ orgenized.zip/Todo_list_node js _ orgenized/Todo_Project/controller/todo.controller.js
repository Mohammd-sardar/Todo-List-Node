const model = require('../model/todo.model')

class todo {

    getAllTodo = () => {
       return async (req , res) => {
            model.getAllTodo().then(data => {
                res.send(data)
            })
            .catch(e => {
                res.send(e)
            })
             
           }
    }

    getTodoByCategory = () => {
        return async(req , res) => {
            const todo_category = req.params.todo_category
            model.getTodoByCategory(todo_category).then(data => {
                res.send(data)
            })
            .catch(e => {
                res.send(e)
            })
          }
    }

    addTodo = () => {
        return async(req , res) => {
            const body = req.body
           model.addTodo(body).then(data => {
            res.send(data)
           })
           .catch(e => {
            res.send(e)
           })
          }
    }

    deleteTodo = () => {
        return async(req , res) => {
            const todo_id = req.params.todo_id
            model.deleteTodo(todo_id).then(data => {
                res.send('deleted')
            })
            .catch(e => {
                res.send(e)
            })
           }
    }

    updateTodo = () => {
        return async (req , res) => {
            const todo_id = req.params.todo_id
            const body = req.body
            
            model.updateTodo(todo_id , body).then(data => {
                res.send('updated')
            })
            .catch(e => {
                res.send(e)
            })
          }
    }
}

module.exports = new todo()