const model = require('../model/categories.model')

class categories {

    getAllCategories = () => {

       return async (req , res) => {
        model.getAllCategory().then(data => {
            res.send(data)
        })
        .catch(e => {
            res.send(e)
        })
            
        }
    }

    addCategory = () => {
       return  async(req , res) => {
            const new_category = req.body
           
                 model.addCategory(new_category).then(data => {
                    res.send(data)
                 })
                 .catch(e => {
                    res.send(e)
                 })
             }
          }
    

    deleteCategory = () => {

       return async(req , res) => {
            const category_id = req.params.category_id

            model.deleteCategory(category_id).then(data => {
                res.send("deleted")
            })
            .catch(e => {
                res.send(e)
            })
          }
    }

    updateCategory = ()=> {
        return async (req , res) => {
            const category_id = req.params.category_id
            const body = req.body
           
            model.updadteCategory(category_id , body).then(data => {
                res.send("updated")
            })
            .catch(e => {
                res.send(e)
            })

          }
    }
}

module.exports = new categories()