const knex = require('../connection')
const table_category = 'categories'

class categoriesModel {

    getAllCategory = async ()=>{
        return await knex.select('*')
              .from(table_category)
    }

    addCategory = async (new_category) => {
       const data = await knex(table_category).insert(new_category)
                 const new_id = data[0]
                 return await knex(table_category)
                 .where('category_id', new_id)
    }

    deleteCategory = async (category_id) =>{
        return await knex(table_category)
          .where('category_id', category_id)
          .del()
    }

    updadteCategory = async (category_id , body) => {
        return await  knex(table_category)
                .where('category_id', category_id)
                .update(body)
    }

}

module.exports = new categoriesModel()