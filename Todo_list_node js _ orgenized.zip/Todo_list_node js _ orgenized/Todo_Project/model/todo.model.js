const knex = require('../connection')
const table_content = 'todo_content'

class todoModel {

    getAllTodo = async ()=>{
        return await knex.select('*')
        .from(table_content)
    }

    getTodoByCategory = async(todo_category) => {
        return await knex(table_content)
           .where('todo_category', todo_category)
    }

    addTodo = async (body) => {
        const data = await knex(table_content).insert(body)
        const new_id = data[0]
        return await knex(table_content)
        .where('todo_id', new_id)
    }

    deleteTodo = async (todo_id) => {
        return await knex(table_content)
        .where('todo_id', todo_id)
        .del()
    }

    updateTodo = async (todo_id , body) => {
        return await  knex(table_content)
        .where('todo_id', todo_id)
        .update(body)
    }
}

module.exports = new todoModel()